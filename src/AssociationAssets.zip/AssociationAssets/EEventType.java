package AssociationAssets;

public enum EEventType {
    OFFSIDE,
    GOAL,
    FOUL,
    REDCARD,
    YELLOWCARD,
    INJURY,
    PLAYERREPLACEMENT
}
